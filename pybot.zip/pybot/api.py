from flask import Flask, request, jsonify
from finance_api import *
from get_bot_response import *
from flask_cors import CORS, cross_origin
from flask_pymongo import PyMongo
import certifi
from dotenv import load_dotenv
import os
from BLlangchaintool import *
import os
from finance_api import makestocktool
from getpredictions import *
from langchain.llms import OpenAI
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage
)
from langchain.chains.conversation.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.prompts.prompt import PromptTemplate
from langchain.chat_models import ChatOpenAI
from langchain.agents import Tool
from blacklitterman import *
from langchain.agents import initialize_agent, AgentType
from pybot_tools import tools

load_dotenv()
app = Flask(__name__)
CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
MONGO_URI =os.getenv("MONGO_URI")
app.config['MONGO_URI'] = MONGO_URI
mongo = PyMongo(app,tlsCAFile=certifi.where())
chat = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.3, openai_api_key=os.getenv("OPENAI_API_KEY"))
memory = ConversationBufferMemory(ai_prefix="AI Assistant",memory_key="chat_history",return_messages=True)

agent = initialize_agent(
agent=AgentType.OPENAI_FUNCTIONS,
tools=tools,
llm=chat,
verbose=True,
max_iterations=3,
early_stopping_method='generate',
memory=memory
)

# memory = ConversationBufferMemory()
# conversation = ConversationChain(
#     llm = chat,
#     verbose=True,
#     memory=memory
# )


def check_user(email, username):
    email_match = False if mongo.db.users.find_one({"email": email}) else True
    username_match = False if mongo.db.users.find_one({"username": username}) else True
    if email_match and username_match:
        return "Successful"
    if not email_match:
        return "Email is already tagged to an account"
    if not username_match:
        return "Username is already taken"
    # mongo.db.users.find(user)
    # find the user to see if username is available

# mongo.init_app(app)
# print(mongo.db)
@app.route("/")
def home():
    return "Home"

# @app.route("/get_ticker/<stock>")
# def get_ticker(stock):
#     ticker = getTicker(stock)
#     res = {
#         "ticker": ticker
#     }
#     return jsonify(res), 200

# @app.route("/get_response", methods = ['POST', 'OPTIONS'])
# @cross_origin()
# def get_response():
#     messages =  request.get_json()["chatters"]
#     template = f"""{messages[0]["content"]}""" + """The assistant, however, is not very good at financial calculations, neither does it have any knowledge about current affairs. To achieve these goals, the agent would always turn to its trusty tools to give accurate answers. Using its trusty tools, it can calculate various things like the black litterman model. The following is the conversation so far. 

#     Current conversation:
#     {history}
#     Human: {input}
#     AI Assistant:"""

#     print(template)
#     PROMPT = PromptTemplate(input_variables=["history", "input"], template=template)
#     conversation = ConversationChain(
#     prompt=PROMPT,
#     llm=chat,
#     verbose=True,
#     memory=memory,
#     # tools = tools
#     )
#     botResponse = get_bot_response(conversation, messages)
#     response = jsonify({"reply": botResponse}) 
#     return response, 200

@app.route("/get_context", methods = ['POST', 'OPTIONS'])
@cross_origin()
def get_context():
    agent(f'use this context for the rest of the conversation: {request.get_json()["chatters"]["content"]}. Do not use tools unless you know all the parameters required.')
    return "ok", 200

@app.route("/get_response", methods = ['POST', 'OPTIONS'])
@cross_origin()
def get_response():
    messages =  request.get_json()["chatters"]
    print("hi")
    response = jsonify({"reply": agent(messages[-1]["content"])['output']}) 
    return response, 200

@app.route("/add_user", methods = ['POST'])
@cross_origin()
def read_database():
    user_data = request.get_json()["user_data"]
    res = check_user(
        user_data["email"], user_data["username"]
    )
    user_collection = mongo.db.users
    if res == "Successful":
        user_collection.insert_one(user_data)
    return res, 200

@app.route("/find_user", methods = ['POST', 'OPTIONS'])
@cross_origin()
def user_return():
    user_data = request.get_json()["user_data"]
    user = mongo.db.users.find_one({'username': user_data['username']})
    print("user is:", user)
    if user:
        res = {
            'password': user['password']
        }
    else:
        res = {'password': None}
    return jsonify(res), 200

@app.route("/add_user_details", methods = ['POST'])
@cross_origin()
def add_data():
    user_data = request.get_json()["user_data"]
    data_collection = mongo.db.user_data
    data_collection.insert_one(user_data)
    return "User data successfully added", 200

@app.route("/add_questionnaire", methods = ['POST'])
@cross_origin()
def add_questionnaire():
    user_data = request.get_json()["user_data"]
    data_collection = mongo.db.questionnaire
    data_collection.insert_one(user_data)
    return "User data successfully added", 200

@app.route("/get_questionnaire", methods = ['POST'])
@cross_origin()
def get_questionnaire():
    user_data = request.get_json()["user_data"]
    username = user_data["username"]
    print(username)
    q_collection = mongo.db.questionnaire
    res = q_collection.find_one(
        {'username': username}
    )
    if res:
        print(res)
        res = {
            'username': res["username"],
            'answers': res["answers"]
        }
        return jsonify(res), 200
    else:
        return jsonify({'questionnaire': False})
if __name__ == "__main__":
    app.run(debug=True)

#ASK THE USER FOR INFORMATION ON HIMSELF
#CAN GET ARTICLES FROM CHATGPT AS SIMULATION
#CAN USE QUATERLY REPORTS ETC
#WHO IS THE TARGET AUDIENCE
#NET WORTH OF THE TARGET AUDIENCE