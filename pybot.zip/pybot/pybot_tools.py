from getpredictions import *
from langchain.tools import tool
from pydantic.v1 import BaseModel, Field
from blacklitterman import *
from typing import List, Tuple, Dict, Union, Optional
from finance_api import * 
from collections import OrderedDict

class Company(BaseModel):
    company: str = Field(
        description="company user would like to find news about.")

class Portfolio_Stock(BaseModel):
    portfolio: List[str] = Field(
        description="list of stocks the user is interested in"
    )
class BLPort(BaseModel):
        portfolio_tickers: List[str] = Field(
        description="List of tickers of stocks the user is interested in"
    )
        portfolio_confidence: List[Tuple] = Field(
        description="Each tuple in the confidence list corresponds to the user's confidence in the view. The tuple consists of two floats: the lower bound (lb) and the upper bound (ub) of the expected return for that asset. These bounds represent the range within which the investor believes the actual return of the asset will fall, based on their view."
    )
        portfolio_views: List[float] = Field(
        description="represents the views of the user. Each float corresponds to the user's view of the expected return from a stock. The position corresponds to that of portfolio_tickers "
    )
        
@tool("analyse_stock", return_direct=False, args_schema=Company)
def sentiment_tool(company: str) -> str:
     """use this tool to analyse a stock's news"""
     tool = NewsSentimentTool()
     return tool.get_sentiment(company)

@tool("summarise_news", return_direct=False, args_schema=Company)
def retrive_news_tool(company: str) -> str:
    """Use this function to obtain news on companies the user is interested in"""
    newstool = NewsSummaryTool()
    res = newstool.get_summary(company)
    return res
@tool("ticker_finder", return_direct=False, args_schema=Portfolio_Stock)
def find_tickers_tool(portfolio: List[str]) -> str:
    """use this function to get the tickers of a portfolio of stocks the user is interested in"""
    res = []
    tickertool = TickerTool()
    for i in portfolio:
        res.append(tickertool.get_tickers(i)) 
    return res
@tool("portfolio_optimiser", return_direct=False, args_schema=BLPort)
def optimise_portfolio_tool(portfolio_tickers: List[str], portfolio_views: List[float], portfolio_confidence: List[Tuple]):
     """use this function to optimise a portfolio the user is interested in, after getting the stocks he is interested in, his views, and his confidence. you need to include all 3 parameters"""
    #  print("hi")  
     try:
        return getOptimal(portfolio_tickers, {portfolio_tickers[i]: portfolio_views[i] for i in range(len(portfolio_tickers))}, portfolio_confidence)
        #   return "hi"
     except:
          return "error, parameters check"


tools = [sentiment_tool, retrive_news_tool, find_tickers_tool, optimise_portfolio_tool]